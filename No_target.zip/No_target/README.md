# No_target — KNN Anonymization (no separate target columns)

This folder is a **self-contained** variant of the KNN anonymization pipeline where
columns like `churn` are treated as **normal categorical QI fields**, not as a
separate `TARGET_COLS` concept.

## Files

| File | Purpose |
|------|---------|
| `production_pipeline.ipynb` | Main batch/single anonymization pipeline |
| `bank_churn_eda.ipynb` | Exploratory analysis (churn as regular categorical) |
| `Bank Customer Churn Prediction.csv` | Dataset |
| `parameter_combinations_filtered.csv` | Filtered experiment grid (80 starter configs) |
| `parameter_combinations.csv` | Full experiment grid (80 starter configs) |
| `parameter_reference.csv` | Parameter definitions, defaults, and No_target notes |
| `filter_parameter_grid.py` | Regenerate filtered grid from full grid |
| `validate_anonymization.py` | Compare original vs `output/anonymized_dataset.csv` — full validation |
| `results/` | Batch experiment rankings |
| `output/` | Single-run / top-config exports |

## Quick start

```bash
cd No_target
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
jupyter notebook production_pipeline.ipynb
```

**Important:** run the notebook with working directory set to `No_target/` (the notebook auto-detects this folder from required files).

All paths are local to this folder — no references to `story02_knn_anonymization/` or `final_folder/`.

## Column config

```python
CATEGORICAL_COLS = ["country", "gender", "churn"]
NUMERICAL_COLS = ["credit_score", "age", ...]
RELATIONSHIP_COL = "churn"   # optional; relationship-drift checks only
```

## Differences from `story02_knn_anonymization/`

- No `TARGET_COLS` / `target_gen_method` synthesis branch
- `churn` included in neighbour distance, k-anonymity, and `cat_gen_method` synthesis
- `target_gen_method` in parameter CSV is ignored (kept for grid compatibility)

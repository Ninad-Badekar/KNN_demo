#!/usr/bin/env python3
"""Validate anonymized output against the original dataset (No_target)."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import chi2_contingency, ks_2samp

ID_COLS = ["customer_id"]
CATEGORICAL_COLS = ["country", "gender", "churn"]
NUMERICAL_COLS = [
    "credit_score", "age", "tenure", "balance",
    "products_number", "credit_card", "active_member", "estimated_salary",
]
QI_COLS = CATEGORICAL_COLS + NUMERICAL_COLS
KANON_QI_COLS = CATEGORICAL_COLS + ["age", "tenure", "products_number", "credit_card", "active_member"]
RELATIONSHIP_COL = "churn"
MISSING_LABEL = "Missing"
TVD_THRESHOLD = 0.10
KS_THRESHOLD = 0.10
PASS_RATE_TARGET = 0.85
RANDOM_STATE = 42


def resolve_root() -> Path:
    candidates = [Path.cwd().resolve(), Path.cwd().resolve() / "No_target", Path(__file__).resolve().parent]
    for p in candidates:
        if (p / "Bank Customer Churn Prediction.csv").exists():
            return p
    raise FileNotFoundError("Could not find No_target folder with Bank Customer Churn Prediction.csv")


def load_config(config_path: Path) -> dict:
    if config_path.exists():
        return json.loads(config_path.read_text())
    return {"k_anonymity": 5, "scaler_method": "standard", "relationship_col": RELATIONSHIP_COL}


def generalize_for_kanonymity(df: pd.DataFrame, qi_cols: list[str]) -> pd.DataFrame:
    g = df[qi_cols].copy()
    if "credit_score" in g.columns:
        g["credit_score"] = (g["credit_score"] // 50) * 50
    if "age" in g.columns:
        g["age"] = (g["age"] // 5) * 5
    if "balance" in g.columns:
        g["balance"] = pd.qcut(g["balance"].rank(method="first"), q=20, duplicates="drop").astype(str)
    if "estimated_salary" in g.columns:
        g["estimated_salary"] = pd.qcut(
            g["estimated_salary"].rank(method="first"), q=20, duplicates="drop"
        ).astype(str)
    for col in g.select_dtypes(include="object").columns:
        g[col] = g[col].astype(str).fillna(MISSING_LABEL)
    for col in CATEGORICAL_COLS:
        if col in g.columns:
            g[col] = g[col].astype(str).fillna(MISSING_LABEL)
    return g


def identify_suppressed(df: pd.DataFrame, k_anonymity: int):
    generalized = generalize_for_kanonymity(df, KANON_QI_COLS)
    class_sizes = generalized.groupby(list(generalized.columns), dropna=False).transform("size")
    suppressed = class_sizes < k_anonymity
    pool_idx = np.where(~suppressed.values)[0]
    synth_idx = np.where(suppressed.values)[0]
    return suppressed, pool_idx, synth_idx


def cramers_v(x, y) -> float:
    tbl = pd.crosstab(x.astype(str), y.astype(str))
    chi2 = chi2_contingency(tbl)[0]
    n = tbl.sum().sum()
    k = min(tbl.shape) - 1
    return float(np.sqrt(chi2 / (n * k))) if n > 0 and k > 0 else 0.0


def structural_checks(df_actual: pd.DataFrame, df_out: pd.DataFrame) -> pd.DataFrame:
    rows = []
    rows.append({"check": "row_count_match", "value": len(df_actual) == len(df_out), "detail": f"{len(df_actual)} vs {len(df_out)}"})
    rows.append({"check": "column_set_match", "value": set(df_actual.columns) == set(df_out.columns), "detail": ""})
    if ID_COLS[0] in df_actual.columns:
        id_match = (df_actual[ID_COLS[0]].astype(str) == df_out[ID_COLS[0]].astype(str)).all()
        rows.append({"check": "customer_id_unchanged", "value": bool(id_match), "detail": ""})
    for col in QI_COLS:
        if col in df_actual.columns:
            changed = int((df_actual[col].astype(str) != df_out[col].astype(str)).sum())
            rows.append({
                "check": f"rows_changed_{col}",
                "value": changed,
                "detail": f"{changed / len(df_actual):.2%} of rows",
            })
    return pd.DataFrame(rows)


def pool_integrity_check(df_actual, df_out, suppressed) -> pd.DataFrame:
    """Non-suppressed rows should match original exactly on QI columns."""
    pool_mask = ~suppressed
    rows = []
    for col in QI_COLS:
        if col not in df_actual.columns:
            continue
        pool_match = (df_actual.loc[pool_mask, col].astype(str) == df_out.loc[pool_mask, col].astype(str)).all()
        mismatches = int((df_actual.loc[pool_mask, col].astype(str) != df_out.loc[pool_mask, col].astype(str)).sum())
        rows.append({
            "column": col,
            "pool_rows_unchanged": bool(pool_match),
            "pool_mismatches": mismatches,
            "pass": bool(pool_match),
        })
    return pd.DataFrame(rows)


def compute_all_metrics(df_actual, df_out, suppressed, relationship_col):
    cat_rows = []
    for col in CATEGORICAL_COLS:
        act = df_actual[col].astype(str)
        syn = df_out[col].astype(str)
        a = act.value_counts(normalize=True)
        s = syn.value_counts(normalize=True)
        tv = 0.5 * sum(abs(s.get(k, 0) - a.get(k, 0)) for k in set(a.index) | set(s.index))
        cat_rows.append({"column": col, "TVD": round(tv, 4), "pass_tvd": tv < TVD_THRESHOLD})
    category_metrics = pd.DataFrame(cat_rows)
    tvd_pass_rate = float(category_metrics["pass_tvd"].mean())

    num_rows = []
    for col in NUMERICAL_COLS:
        act, syn = df_actual[col].astype(float), df_out[col].astype(float)
        ks_stat, ks_p = ks_2samp(act, syn)
        num_rows.append({
            "column": col,
            "KS_statistic": round(ks_stat, 4),
            "KS_pvalue": round(ks_p, 4),
            "pass_ks": ks_stat < KS_THRESHOLD,
        })
    numeric_metrics = pd.DataFrame(num_rows)
    ks_pass_rate = float(numeric_metrics["pass_ks"].mean())

    relationship_rows = []
    if relationship_col and relationship_col in df_actual.columns:
        for col in [c for c in QI_COLS if c != relationship_col]:
            if relationship_col in CATEGORICAL_COLS or df_actual[relationship_col].nunique() <= 20:
                v_a = cramers_v(df_actual[col], df_actual[relationship_col])
                v_s = cramers_v(df_out[col], df_out[relationship_col])
                relationship_rows.append({
                    "label": relationship_col, "column": col, "metric": "cramers_v",
                    "actual": round(v_a, 4), "synthetic": round(v_s, 4),
                    "drift": round(abs(v_a - v_s), 4),
                    "pass_drift": abs(v_a - v_s) < 0.05,
                })
            elif col in NUMERICAL_COLS:
                c_a = df_actual[col].astype(float).corr(df_actual[relationship_col].astype(float))
                c_s = df_out[col].astype(float).corr(df_out[relationship_col].astype(float))
                if pd.notna(c_a) and pd.notna(c_s):
                    relationship_rows.append({
                        "label": relationship_col, "column": col, "metric": "correlation",
                        "actual": round(float(c_a), 4), "synthetic": round(float(c_s), 4),
                        "drift": round(abs(float(c_a) - float(c_s)), 4),
                        "pass_drift": abs(float(c_a) - float(c_s)) < 0.05,
                    })
    relationship_metrics = pd.DataFrame(relationship_rows)
    mean_corr_drift = float(relationship_metrics["drift"].mean()) if len(relationship_metrics) else 0.0

    feature_cols = [c for c in df_actual.columns if c not in ID_COLS]
    replaced_idx = suppressed[suppressed].index
    exact_match_rate = len(
        df_out.loc[replaced_idx, feature_cols].merge(df_actual[feature_cols], how="inner")
    ) / max(len(replaced_idx), 1)

    scorecard = pd.DataFrame([
        {"area": "Quality-Categorical", "metric": "tvd_pass_rate>=0.85", "value": round(tvd_pass_rate, 4), "pass": tvd_pass_rate >= PASS_RATE_TARGET},
        {"area": "Quality-Numerical", "metric": "ks_pass_rate>=0.85", "value": round(ks_pass_rate, 4), "pass": ks_pass_rate >= PASS_RATE_TARGET},
        {"area": "Quality-Numerical", "metric": "mean_KS<0.10", "value": round(numeric_metrics["KS_statistic"].mean(), 4), "pass": numeric_metrics["KS_statistic"].mean() < KS_THRESHOLD},
        {"area": "Relationships", "metric": "mean_corr_drift<0.05", "value": round(mean_corr_drift, 4), "pass": mean_corr_drift < 0.05},
        {"area": "Privacy", "metric": "replaced_exact_match_rate<0.001", "value": round(exact_match_rate, 6), "pass": exact_match_rate < 0.001},
        {"area": "Suppression", "metric": "recovery_rate", "value": 1.0, "pass": suppressed.sum() > 0},
    ])
    overall_pass = bool(scorecard["pass"].all())

    summary = {
        "overall_pass": overall_pass,
        "tvd_pass_rate": round(tvd_pass_rate, 4),
        "ks_pass_rate": round(ks_pass_rate, 4),
        "mean_tvd": round(category_metrics["TVD"].mean(), 4),
        "mean_ks": round(numeric_metrics["KS_statistic"].mean(), 4),
        "mean_corr_drift": round(mean_corr_drift, 6),
        "exact_match_rate": round(exact_match_rate, 6),
        "n_suppressed": int(suppressed.sum()),
        "n_pool": int((~suppressed).sum()),
        "relationship_col": relationship_col,
    }
    return category_metrics, numeric_metrics, relationship_metrics, scorecard, summary


def compare_with_pipeline_scorecard(new_scorecard: pd.DataFrame, pipeline_scorecard_path: Path) -> pd.DataFrame:
    if not pipeline_scorecard_path.exists():
        return pd.DataFrame()
    old = pd.read_csv(pipeline_scorecard_path)
    merged = new_scorecard.merge(old, on=["area", "metric"], suffixes=("_validation", "_pipeline"), how="outer")
    if "value_validation" in merged.columns and "value_pipeline" in merged.columns:
        merged["value_diff"] = merged["value_validation"] - merged["value_pipeline"]
    if "pass_validation" in merged.columns and "pass_pipeline" in merged.columns:
        merged["pass_match"] = merged["pass_validation"] == merged["pass_pipeline"]
    return merged


def run_validation(
    root: Path,
    original_path: Path | None = None,
    anonymized_path: Path | None = None,
    config_path: Path | None = None,
    output_dir: Path | None = None,
) -> dict:
    root = root.resolve()
    original_path = original_path or root / "Bank Customer Churn Prediction.csv"
    anonymized_path = anonymized_path or root / "output" / "anonymized_dataset.csv"
    config_path = config_path or root / "output" / "config.json"
    output_dir = output_dir or root / "output" / "validation"
    output_dir.mkdir(parents=True, exist_ok=True)

    cfg = load_config(config_path)
    k_anonymity = int(cfg.get("k_anonymity", 5))
    scaler_method = str(cfg.get("scaler_method", "standard"))
    relationship_col = cfg.get("relationship_col") or cfg.get("utility_col") or RELATIONSHIP_COL

    df_actual = pd.read_csv(original_path)
    df_out = pd.read_csv(anonymized_path)
    df_actual = df_actual.replace(r"^\s*$", np.nan, regex=True)

    suppressed, pool_idx, synth_idx = identify_suppressed(df_actual, k_anonymity)

    structural = structural_checks(df_actual, df_out)
    pool_check = pool_integrity_check(df_actual, df_out, suppressed)
    category_metrics, numeric_metrics, relationship_metrics, scorecard, summary = compute_all_metrics(
        df_actual, df_out, suppressed, relationship_col
    )
    pipeline_compare = compare_with_pipeline_scorecard(scorecard, root / "output" / "scorecard.csv")

    dist_rows = []
    for col in NUMERICAL_COLS:
        dist_rows.append({
            "column": col,
            "actual_mean": round(df_actual[col].mean(), 4),
            "synthetic_mean": round(df_out[col].mean(), 4),
            "actual_std": round(df_actual[col].std(), 4),
            "synthetic_std": round(df_out[col].std(), 4),
            "mean_diff_pct": round(abs(df_out[col].mean() - df_actual[col].mean()) / max(abs(df_actual[col].mean()), 1e-6) * 100, 2),
        })
    distribution_summary = pd.DataFrame(dist_rows)

    structural.to_csv(output_dir / "structural_checks.csv", index=False)
    pool_check.to_csv(output_dir / "pool_integrity.csv", index=False)
    category_metrics.to_csv(output_dir / "category_metrics.csv", index=False)
    numeric_metrics.to_csv(output_dir / "numeric_metrics.csv", index=False)
    relationship_metrics.to_csv(output_dir / "relationship_metrics.csv", index=False)
    scorecard.to_csv(output_dir / "scorecard.csv", index=False)
    distribution_summary.to_csv(output_dir / "distribution_summary.csv", index=False)
    if len(pipeline_compare):
        pipeline_compare.to_csv(output_dir / "scorecard_vs_pipeline.csv", index=False)

    report = {
        **summary,
        "config": cfg,
        "paths": {
            "original": str(original_path),
            "anonymized": str(anonymized_path),
            "validation_output": str(output_dir),
        },
    }
    (output_dir / "validation_summary.json").write_text(json.dumps(report, indent=2))

    print(f"Validation output → {output_dir}")
    print(f"overall_pass: {summary['overall_pass']}")
    print(f"suppressed: {summary['n_suppressed']} | pool: {summary['n_pool']}")
    print(f"TVD pass rate: {summary['tvd_pass_rate']} | KS pass rate: {summary['ks_pass_rate']}")
    print(f"Mean relationship drift: {summary['mean_corr_drift']}")
    print("\nScorecard:")
    print(scorecard.to_string(index=False))
    return report


def main():
    parser = argparse.ArgumentParser(description="Validate anonymized dataset vs original (No_target)")
    parser.add_argument("--root", type=Path, default=None, help="No_target folder path")
    parser.add_argument("--original", type=Path, default=None)
    parser.add_argument("--anonymized", type=Path, default=None)
    parser.add_argument("--config", type=Path, default=None)
    parser.add_argument("--out", type=Path, default=None, help="Validation output directory")
    args = parser.parse_args()

    root = args.root or resolve_root()
    run_validation(root, args.original, args.anonymized, args.config, args.out)


if __name__ == "__main__":
    main()
